<?php
    $dbhost = "localhost";
    $dbname = "id14879459_db_transaksi";
    $dbuser = "id14879459_daffa_aldzakian";
    $dbpassword = "UE5O1fh#cPbe5nQM";

$koneksi = mysqli_connect($dbhost,$dbuser,$dbpassword) or die("Koneksi ke Server Error !");
mysqli_select_db($dbname,$koneksi) or die("Koneksi ke Database Error !");

?>